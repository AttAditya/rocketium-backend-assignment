const generation = require("./generation");
const sorting = require("./sorting");

module.exports = {
    ...generation,
    ...sorting
};